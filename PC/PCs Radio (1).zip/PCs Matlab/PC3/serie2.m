function S2 = serie2(x, N)
    % Inicializar la suma de la serie
    S2 = 0;

    % Calcular la suma de los primeros N términos de la serie
    for n = 0:N-1
        term = ((-1)^n * x^(2*n + 1)) / ((2*n + 1) * factorial(2*n + 1));
        S2 = S2 + term;
    end
end
