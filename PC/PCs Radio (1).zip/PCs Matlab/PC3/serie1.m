function S1 = serie1(x, N)
    % Inicializar la suma de la serie
    S1 = 0;

    % Calcular la suma de los primeros N términos de la serie
    for n = 1:N
        term = ((-1)^(n+1) * x^(2*n)) / (2*n * factorial(2*n));
        S1 = S1 + term;
    end
end
