close all;
clearvars;
clc;

d=11000;
phi=deg2rad(2);
f=30*10^6;
c=3*10^8;
ht=35;
hr=20;
lambda=c/f;
sigma=10^-3;
er=15;
e0=er-1i*60*sigma*lambda;

numRv=e0*sin(phi)-sqrt(e0-cos(phi)^2);
denRv=e0*sin(phi)+sqrt(e0-cos(phi)^2);

Rv=numRv./denRv;
R=abs(Rv);
betha=-rad2deg(angle(Rv));

Z=(sqrt(e0-cos(phi)^2))./e0;
A=-1./(1+1i*2*pi*d/lambda*(sin(phi)+Z)^2);
delta=(4*pi*ht*hr)./(lambda*d);
%parte a
e=e0*(1+R*exp(-1i*delta)+(1-R)*A*exp(-1i*delta));

%parte b
d1=(d*ht)./(ht+hr);
d2=(d*hr)./(ht+hr);

%parte c
numlb=(4*pi*d./lambda)^2;
denlb=sqrt(1+2*R*cosd(delta*(pi/180)+betha)+R^2);
lb=numlb./denlb;
lb_db=20*log10(lb);