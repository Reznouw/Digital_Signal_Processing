close all;
clearvars;
clc;

d=20000;
f=80*10^6;
c=3*10^8;
ht=20;
hr=35;
lambda=c/f;
sigma=0.0018;
er=15;
e0=er-1i*60*sigma*lambda;
h=0.4;
N0=320;
x=d/2;

R0=6370000;
R01=6370;
Ns=N0*exp(-0.136*h);
%parte a
N=Ns*(1-0.136*h);

%parte b
rro=Ns*1.36*10^(-7);
R=1./rro;

%parte c
k=R/(R-R01);
bE=(x*(d-x))./(2*k*R0);
